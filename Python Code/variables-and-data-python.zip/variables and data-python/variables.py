# Variable declaration and Assignment
# name = "Ronaldo"
# num = 7
# age = 34

# Multi-Assignment within a single statement
name, num, age = "Ronaldo", 7, 34

# get the output
# print(name)
# print(num)
# print(age)

# output multi values
# print(name, num, age)
# print("The player name is " , name, ", his age is ", age, " and his number is " , num)
print("The Player name is " + name + " and his age is " + str(age))

