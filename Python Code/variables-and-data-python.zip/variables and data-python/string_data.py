# string data to represent text
# string_data = "Hello Everyone!!, 12345 $$// 'anything' \"double quotes\""
# print(string_data)
# print(len(string_data)) # get length

#store numbers inside string
# x = 5
# y = "5"
# print(str(x) + y)
# print("5" + "5") # 55
# print(5 + 5)  # 10