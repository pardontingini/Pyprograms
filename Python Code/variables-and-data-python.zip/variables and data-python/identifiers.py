# identifiers are case sensitive
# sport = 'Football'
# Sport = 'Tennis'

# # get output
# # print(sport, " and ", Sport)

# # get type of sport
# print(type(sport))

number = 10
print(type(number))






