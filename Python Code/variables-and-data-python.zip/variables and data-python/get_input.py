# use the input function
get_name = input('What is your name?')

# get the output
print('Your name is: ' + get_name)


