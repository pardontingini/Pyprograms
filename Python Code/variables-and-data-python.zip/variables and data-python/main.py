# hello world app
print('Hello, World!')