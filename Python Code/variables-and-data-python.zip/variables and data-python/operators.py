# Arithmetic operators
# print(100 + 70)
# print(90 - 10)
# print(10 * 4)
# print(12 / 4)
# print(15 % 2)
# print(12 // 4)
# print(3 ** 5)
# Comparison operators
# print(3 == 3)
# print(2 == 3)
# print( 10 > 11 )
# print(20 >= 15)
# print(30 <= 18)
# Logical operators
# print(5 == 5 and 10 == 10)
# print(10 == 10 and 10 == 11)
# print(10 == 10 or 10 == 11)
# print(not True)
# Assignment operators
# x = 5 + 10
# print(x)
# x = 10
# x += 5
# print(x)
# a = 5
# a /= 2
# print(a)

# Conditional operators
name = "python"
print("False!" if name != "python" else "True!")