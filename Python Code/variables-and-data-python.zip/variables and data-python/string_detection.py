# string detection
# x = "567hello"
# y = "101010"

# using isnumeric
# print(x.isnumeric())  # False
# print(y.isnumeric()) # True
# print("Hello\nPython developers!")
use_triple = '''multi
\\line
string''' 
print(use_triple)                