# numbers data
# x = 3
# y = 5.12
# z = 5 - 2.12j

# display the type of numbers
# print(type(x))
# print(type(y))
# print(type(z))

# using random module
# import random
# print(random.random())
# print(random.randint(1, 50))
# print(random.choice([30, 40, 50, 60, 70, 80]))
# print(random.sample([30, 40, 50, 60, 70], 4))