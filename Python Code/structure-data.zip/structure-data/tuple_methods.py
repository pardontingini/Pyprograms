# list inside tuple
# mixed = ("Apple", [10, 20, 30])
# print(mixed)

# access item
fruits = ("apple", "orange", "lemon", "fig")
# print(fruits[2]) # lemon
# print(fruits[0:3])