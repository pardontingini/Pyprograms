# tuple concatenation
fruits1 = ("fig", "apple", "banana")
# fruits2 = ("lemon", "orange")
# allfruits = fruits1 + fruits2
# print(allfruits)  
del fruits1
print(fruits1)
