# change item
# fruits = ["banana", "lemon", "apple", "orange"]
# fruits[2] = "fig"
# print(fruits)

# append item
# fruits = ["banana", "lemon", "apple", "orange"]
# fruits.append("another fruit")
# print(fruits)

#del item
fruits = ["banana", "lemon", "apple", "orange"]
del fruits[1]
print(fruits)
