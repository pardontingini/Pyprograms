# create a fruit price dict
# fruit_price = {"Apple": [5, 6, 7], "banana": 4, "fig": 3}
# print(fruit_price["Apple"]) # 5
# print(fruit_price.get("banana")) # 4
# print(fruit_price.get("orange"))
# print(fruit_price["Apple"][1])