# create a tuple
# players = ("Ronaldo", "Messi", "Pogba", "Modric")
# players2 = "Salah", "Mane"
# print(players)
# print(players2)

# create single item tuple
# fruit = ("lemon")
# fruit2 = ("orange",)
# print(fruit)
# print(fruit2)
