# player number dict 
player_number = {"Messi": 10, "Ronaldo": 7, "Salah": 11}

# update Ronaldo number 
# player_number["Ronaldo"] = 17
# print(player_number)

# add item
# player_number["Pogba"] = 6
# print(player_number)

# delete Ronaldo item
# del player_number["Ronaldo"]
del player_number
print(player_number)