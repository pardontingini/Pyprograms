#create a list
# players = ['Ronaldo', 'Messi', 'Salah', 'Mane']
# print(players)

# list contain any data
mixed = ["Hi", [5, 6, 7], 278, True]
print(mixed)
