# create a dictionary
player_number = {"Messi": 10, "Ronaldo": 7, "Salah": 11}
# player_number = dict({"Messi": 10, "Ronaldo": 7, "Salah": 11})

# print(player_number)
# print(type(player_number))
