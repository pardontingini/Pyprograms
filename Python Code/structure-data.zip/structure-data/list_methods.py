# return number of items
# cars = ["BMW", "Volvo", "Audi"]
# print(len(cars))  

# Access items
cars = ["BMW", "Volvo", "Audi"]
print(cars[0])  # BMW
print(cars[1])  # Volvo
print(cars[0:2]) #["BMW", "Volvo"]
print(cars[-2]) # Volvo