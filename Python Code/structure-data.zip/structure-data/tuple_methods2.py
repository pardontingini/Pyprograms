# update tuple items
fruits = ("orange", "banana", "lemon")
print(fruits)

# reassign items
fruits = ("apple", "fig")
print(fruits)
