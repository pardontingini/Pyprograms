# Ternary Operator
x = 1
print("Smaller than 10" if x < 10 else "Anything else!")