# else statement example
num = 50

if num > 55:
    print("This is True for if statement!")
else:
    print("anything else!")