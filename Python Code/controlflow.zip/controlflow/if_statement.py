# if statement example
num = 60

if num > 55:
    print("This is True for if statement!")
    