# while loop with else
num = 1
while (num < 8):
    num = num + 1
    print(num)
      