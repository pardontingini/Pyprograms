# elif statement example
num = 50

if num > 55:
    print("This is True for if statement!")
elif 55 > num >= 50:
    print("This is the best choice for elif!")
else:
    print("anything else!")