#break statement
num = 1
while(num < 8):
    print(num)
    num = num + 1
    if num == 4:
        break